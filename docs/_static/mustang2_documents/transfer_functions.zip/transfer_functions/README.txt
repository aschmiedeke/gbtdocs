naming convention as follows: xfer_Function_daisyRad_filteringType
- daisyRad = the radius of the daisy in arcmin (e.g., 2p5 is 2.5')
- filteringType = standard or light filtering as described below

Transfer functions with "standard/moderate" filtering (PCA=5, high pass = 0.08 Hz)
- xfer_Function_2p5_standardFiltering.txt
- xfer_Function_3p0_standardFiltering.txt
- xfer_Function_3p5_standardFiltering.txt
- xfer_Function_4p0_standardFiltering.txt
- xfer_Function_4p5_standardFiltering.txt
- xfer_Function_5p0_standardFiltering.txt

Transfer functions by scan size with "light" filtering (PCA=3, high pass = 0.06 Hz)
- xfer_Function_2p5_lightFiltering.txt
- xfer_Function_3p0_lightFiltering.txt
- xfer_Function_3p5_lightFiltering.txt
- xfer_Function_4p0_lightFiltering.txt
- xfer_Function_4p5_lightFiltering.txt
- xfer_Function_5p0_lightFiltering.txt

Notes:
- for a high-pass of 0.07 and higher, sufficient agreement should be found with the transfer functions for "standard/moderate" filtering. Below 0.07, it should be sufficient to use the transfer functions for "light" filtering. 
- PCA = the number of principle components which are removed from the TODs. For PCA = 5 the number of principle components which are removed from the TODs is 5.
- high pass = high-pass filter frequency. High-pass means frequencies higher than it get passed through. For example, "high pass = 0.08 Hz" means that less than 0.08 Hz is filtered out.

Contact the MUSTANG-2 instrument team (mustangsz-at-googlegroups-dot-com) with any questions.

Creator of transfer functions: Charles Romero (2022). 